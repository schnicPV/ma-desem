var searchData=
[
  ['header_5fsize_70',['HEADER_SIZE',['../classdesenet_1_1Frame.html#a94aa51569dd3f26cd2c0ea23c32fd220',1,'desenet::Frame']]],
  ['hour_71',['hour',['../classTTime.html#a2ddcb3d7e40393e7ba64d2f6c6043e42',1,'TTime']]]
];
