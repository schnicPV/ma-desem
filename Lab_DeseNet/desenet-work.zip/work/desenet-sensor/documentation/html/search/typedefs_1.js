var searchData=
[
  ['receptioncallbackhandler_321',['ReceptionCallbackHandler',['../classdesenet_1_1NetworkInterfaceDriver.html#a6824deb5b793fad68b42d09b24d06cb5',1,'desenet::NetworkInterfaceDriver']]]
];
