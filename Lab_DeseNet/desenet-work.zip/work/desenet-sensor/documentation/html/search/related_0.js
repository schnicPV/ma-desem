var searchData=
[
  ['operator_3c_3c_336',['operator&lt;&lt;',['../classdesenet_1_1Frame.html#a8a17c1d8f0cfad86dd08ddf15511f8ce',1,'desenet::Frame']]]
];
