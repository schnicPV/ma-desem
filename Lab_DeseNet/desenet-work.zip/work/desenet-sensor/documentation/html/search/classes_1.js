var searchData=
[
  ['beacon_170',['Beacon',['../classdesenet_1_1Beacon.html',1,'desenet']]]
];
