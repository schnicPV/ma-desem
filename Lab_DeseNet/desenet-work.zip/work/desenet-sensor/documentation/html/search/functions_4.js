var searchData=
[
  ['data_208',['data',['../classhei_1_1SharedBuffer.html#a3f638c571b8f350d04af335b4d2d4ed0',1,'hei::SharedBuffer::data()'],['../classhei_1_1SharedBuffer.html#ac8e21616706cef083f481d9ca7e6c149',1,'hei::SharedBuffer::data() const']]],
  ['descriptor_209',['Descriptor',['../classdesenet_1_1NetworkInterfaceDriver_1_1Descriptor.html#a6a16e1d6564c962e4591f29a1e98466a',1,'desenet::NetworkInterfaceDriver::Descriptor']]],
  ['destination_210',['destination',['../classdesenet_1_1Frame.html#a570949c8c3c8dc5d63e2693a28eeb60a',1,'desenet::Frame']]],
  ['drawline_211',['drawLine',['../classMonochromeDisplayPainter.html#ab84b605aaf99b13f45f88ce7be8b40d8',1,'MonochromeDisplayPainter']]],
  ['drawpixel_212',['drawPixel',['../classMonochromeDisplayPainter.html#a00d78a4c3f982937bd5e3a7ea37e2bda',1,'MonochromeDisplayPainter']]],
  ['drawrectangle_213',['drawRectangle',['../classMonochromeDisplayPainter.html#adefdf17da35c62da58bead38906d44d9',1,'MonochromeDisplayPainter']]],
  ['drawtext_214',['drawText',['../classMonochromeDisplayPainter.html#a19faf7a65aae56046e699c9513623d5d',1,'MonochromeDisplayPainter']]]
];
