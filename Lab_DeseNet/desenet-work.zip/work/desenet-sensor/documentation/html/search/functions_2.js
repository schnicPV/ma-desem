var searchData=
[
  ['beacon_195',['Beacon',['../classdesenet_1_1Beacon.html#a2566f46598c15340fcda82ab94e020d4',1,'desenet::Beacon::Beacon(uint32_t cycleInterval=0)'],['../classdesenet_1_1Beacon.html#a95e5906a5e18c99bf62115de76da6ec5',1,'desenet::Beacon::Beacon(const Frame &amp;frame)']]],
  ['begin_196',['begin',['../classhei_1_1SharedBuffer.html#aece7bb3af3cbae8d10aa90b286f0ac07',1,'hei::SharedBuffer::begin()'],['../classMonochromeDisplayPainter.html#a8ce700bbae2cbd73147e60609c46c8d6',1,'MonochromeDisplayPainter::begin()']]],
  ['buffer_197',['buffer',['../classdesenet_1_1Frame.html#a1cdd016bedc5b4fa03fcffe8c67d1c96',1,'desenet::Frame::buffer()'],['../classdesenet_1_1Frame.html#a20c35482fc9525af7c9bae1d2f727508',1,'desenet::Frame::buffer() const']]]
];
