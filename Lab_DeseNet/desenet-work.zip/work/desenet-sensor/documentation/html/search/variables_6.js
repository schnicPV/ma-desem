var searchData=
[
  ['size_319',['SIZE',['../classdesenet_1_1Beacon.html#a114135c402bf65fc4935507672350876',1,'desenet::Beacon']]]
];
