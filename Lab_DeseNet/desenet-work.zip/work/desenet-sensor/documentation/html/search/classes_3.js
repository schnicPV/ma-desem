var searchData=
[
  ['descriptor_172',['Descriptor',['../classdesenet_1_1NetworkInterfaceDriver_1_1Descriptor.html',1,'desenet::NetworkInterfaceDriver']]]
];
