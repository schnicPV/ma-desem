var searchData=
[
  ['factory_60',['Factory',['../classapp_1_1Factory.html',1,'app']]],
  ['footer_5fsize_61',['FOOTER_SIZE',['../classdesenet_1_1Frame.html#a62c6573e3d4f093713945b90d5952a68',1,'desenet::Frame']]],
  ['frame_62',['Frame',['../classdesenet_1_1Frame.html',1,'desenet::Frame'],['../classdesenet_1_1Frame.html#a45da075af2d45001db031208c55ac743',1,'desenet::Frame::Frame()']]],
  ['friendlyname_63',['friendlyName',['../classdesenet_1_1NetworkInterfaceDriver_1_1Descriptor.html#ad1dfd130dfc71984ad9d0f42bc911413',1,'desenet::NetworkInterfaceDriver::Descriptor']]],
  ['fromhexstring_64',['fromHexString',['../classphy_1_1Address.html#ae2a746743950db904bb3119624d2040c',1,'phy::Address']]],
  ['frequently_20asked_20questions_65',['Frequently asked Questions',['../sec_faq.html',1,'index']]]
];
