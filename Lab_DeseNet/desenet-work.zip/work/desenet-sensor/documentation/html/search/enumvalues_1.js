var searchData=
[
  ['ev_5fminute_5felapsed_5fid_328',['EV_MINUTE_ELAPSED_id',['../classClockwork.html#ad38742b1315bb5f01b934d3b80b8f6e6a7f2e9f5fcb87338ab6f36c485555974c',1,'Clockwork']]],
  ['ev_5fsv_5fsync_5fid_329',['EV_SV_SYNC_id',['../classapp_1_1AccelerometerApplication.html#a7ab421d3dbddb130eeba0ad47ae490f9afc9b59a9e6650dabf1c5e24b87fa49d9',1,'app::AccelerometerApplication']]]
];
