var searchData=
[
  ['descriptorlist_320',['DescriptorList',['../classdesenet_1_1NetworkInterfaceDriver.html#aab790233cce6767d45c664446afea3c6',1,'desenet::NetworkInterfaceDriver']]]
];
