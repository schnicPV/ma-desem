var searchData=
[
  ['own_5fslot_5ffinish_330',['OWN_SLOT_FINISH',['../classITimeSlotManager.html#a02c5458442d77348efab58d52667d6cca273b5ca04621c386204ea50e49ae368c',1,'ITimeSlotManager']]],
  ['own_5fslot_5fstart_331',['OWN_SLOT_START',['../classITimeSlotManager.html#a02c5458442d77348efab58d52667d6ccaddc4183949e82f900a53f1b8f3ad26ed',1,'ITimeSlotManager']]]
];
