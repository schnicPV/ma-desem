#ifndef BSTATE_H
#define BSTATE_H
enum BState
{
    PRESSED,
    RELEASED
};
#endif // BSTATE_H
