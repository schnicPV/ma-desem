#ifndef BOARD_H
#define BOARD_H

/**
 * @brief Board specific code and functions.
 */

namespace board
{
	void initialize();		///< Board specific initialization
}

#endif
