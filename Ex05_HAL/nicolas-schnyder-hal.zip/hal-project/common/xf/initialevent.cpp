#include "xf.h"
#include "initialevent.h"

InitialEvent::InitialEvent()
    : IXFEvent(IXFEvent::Initial, 0, NULL)
{
}

InitialEvent::~InitialEvent()
{

}
