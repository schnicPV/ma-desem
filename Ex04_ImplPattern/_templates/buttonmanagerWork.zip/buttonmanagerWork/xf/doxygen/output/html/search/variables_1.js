var searchData=
[
  ['shoulddelete',['shouldDelete',['../struct_i_x_f_event_1_1__t_event_status.html#a5c49551d244e0aa209caa81288825a22',1,'IXFEvent::_tEventStatus']]]
];
