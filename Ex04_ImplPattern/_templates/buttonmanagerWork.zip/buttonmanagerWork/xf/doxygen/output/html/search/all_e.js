var searchData=
[
  ['_7eixfevent',['~IXFEvent',['../class_i_x_f_event.html#a7a2e81d1f8046b2acd61dfe85423a66e',1,'IXFEvent']]]
];
