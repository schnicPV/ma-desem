#ifndef COMMON_TESTS_UNITTEST_H
#define COMMON_TESTS_UNITTEST_H

/*
 * @brief Base class for every unit test
 */
class UnitTest
{
public:
	UnitTest() {}
	virtual ~UnitTest() {}
};

#endif // COMMON_TESTS_UNITTEST_H
