#ifndef BOARD_H
#define BOARD_H

namespace board
{
	void initialize();		///< Board specific initialization
}

#endif
