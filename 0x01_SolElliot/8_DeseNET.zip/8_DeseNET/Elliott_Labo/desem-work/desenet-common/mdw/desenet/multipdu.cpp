/*
 * multipdu.cpp
 *
 *  Created on: Dec 9, 2019
 *      Author: desem
 */

#include <multipdu.h>

using namespace desenet;

#define SENSOR_ID DESENET_SLOT_NUMBER // from platform-config.h

// create a frame with 32 bytes
MultiPDU::MultiPDU(): Frame(Frame::HEADER_SIZE + 2 + 30 + Frame::FOOTER_SIZE),
		sampledValuesBuffer(7)
{
	// TODO Auto-generated constructor stub

	setDestination(GATEWAY_ADDRESS); // never changes

	// bit 7 of 1st byte
	setType(FrameType::MPDU); // that is an mpdu
	// static set of id number
	uint8_t firstByte = 0x80;//(uint8_t) type(); // MSB set => that is an mpdu
	firstByte |= (SENSOR_ID & 0x7f); // put the sensor id to the first byte
	memcpy(buffer() + Frame::HEADER_SIZE, &firstByte, sizeof(firstByte)); // copy into the frame buffer

	// set 2nd byte that is ePDU count (0 at start)
	uint8_t epduCount = 0;
	memcpy(buffer() + Frame::HEADER_SIZE + 1, &epduCount, sizeof(epduCount)); // copy new ePDU count to frame buffer

	// update the length of the frame
	// by default there is :
	// HEADER_SIZE
	// 1st byte : FrameType | SensorID
	// 2nd byte : ePDU count
	// FOOTER_SIZE
	setLength(Frame::HEADER_SIZE + 2 + Frame::FOOTER_SIZE); // Only the header, the footer, and the 2 first obligatory fields of the payload are present.
}

MultiPDU::~MultiPDU() {
	// TODO Auto-generated destructor stub
}

SharedByteBuffer& MultiPDU::getSampledValuesBuffer()
{
	return sampledValuesBuffer;
}

/**
 * update the content of the frame
 */
void MultiPDU::updateMPDU(SvGroup group, SharedByteBuffer::sizeType appDataLength)
{
	/**
	 * an SV ePDU is :
	 * 1 byte with : ePDU_TYPE (0 on MSB) + SV_GROUP (4 bits) + nbBytesLength (3 LSB)
	 * others bytes : payload
	 */

	// check if space into frame
	if(appDataLength < reservedLength() - length()) // "constantLength - actualLength"
	{
		// create 1st byte of ePDU
		uint8_t epduFirstB = 0;
		epduFirstB = epduFirstB | (group << 3);
		epduFirstB = epduFirstB | (appDataLength);
		uint8_t actualBufferLength = length();
		memcpy(buffer() + actualBufferLength, &epduFirstB, sizeof(epduFirstB)); // copy first byte into buffer
		memcpy(buffer() + actualBufferLength + 1, sampledValuesBuffer.data(), sizeof(appDataLength)); // copy payload into buffer
		actualBufferLength++;
		setLength(actualBufferLength + appDataLength);
		// update ePDU count

		uint8_t epduCount = 0;
		memcpy(&epduCount, buffer() + Frame::HEADER_SIZE + 1, sizeof(epduCount)); // get ePDU count
		epduCount++;
		memcpy(buffer() + Frame::HEADER_SIZE + 1, &epduCount, sizeof(epduCount)); // set new ePDU count
	}

}

/**
 * @brief clean the multipdu
 */
void MultiPDU::clean()
{
	uint8_t ePDUCount = 0;
	memcpy(buffer() + Frame::HEADER_SIZE + 1, &ePDUCount, sizeof(ePDUCount)); // pdu count reset to zero
	setLength(Frame::HEADER_SIZE + 2 + Frame::FOOTER_SIZE); // same as init
}

/**
 * @briead try to insert an event into the multipdu
 */
bool MultiPDU::tryInsertEv(desenet::EvId eventId, const SharedByteBuffer& data)
{
	/**
	 * an EV ePDU is :
	 * 1 byte with : ePDU_TYPE (1 on MSB) + Event ID (4 bits) + nbBytesLength (3 LSB)
	 * others bytes : payload
	 */

	// check if space into frame
	// +1 because of the firstByte (Header of event PDU)
	if (data.length()+1 <= reservedLength() - length()) { // "constantLength - actualLength"
		// create 1st byte of ePDU
		uint8_t epduFirstB = 0x80; // 1st Byte with Event ePDU type
		epduFirstB = epduFirstB | (eventId << 3);
		epduFirstB = epduFirstB | (data.length());

		memcpy(buffer() + (int8_t)length(), &epduFirstB, sizeof(epduFirstB)); /// copy first byte into buffer
		memcpy(buffer() + (int8_t)length() + 1, data.data(), data.length()); // copy payload into buffer
		setLength(length() + data.length() + 1); // update frame length

		// updadte the pdu counter
		uint8_t epduCount = 0;
		memcpy(&epduCount, buffer() + Frame::HEADER_SIZE + 1, sizeof(epduCount)); // get ePDU count
		epduCount++;
		memcpy(buffer() + Frame::HEADER_SIZE + 1, &epduCount, sizeof(epduCount)); // set new ePDU count

		return true;
	} else return false;
}
