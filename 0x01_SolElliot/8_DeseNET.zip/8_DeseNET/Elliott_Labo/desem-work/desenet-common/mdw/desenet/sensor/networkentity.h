#ifndef SENSOR_NETWORK_ENTITY_H
#define SENSOR_NETWORK_ENTITY_H

#include <assert.h>
#include <list>
#include <array>
#include "platform-config.h"
#include "desenet/desenet.h"
#include "desenet/networkinterfacedriver.h"
#include "itimeslotmanager.h"
#include "multipdu.h"

using desenet::NetworkInterfaceDriver;
using namespace desenet;

class LedController;

namespace desenet {
namespace sensor {

class AbstractApplication;
class Net;

/**
 * @brief Implements the desenet protocol on the network layer.
 */
class NetworkEntity: public ITimeSlotManager::Observer
{
	friend class AbstractApplication;
	friend class Net;

public:
	NetworkEntity();
	virtual ~NetworkEntity();

	void initialize();																						///< Initializes the instance.
	void initializeRelations(ITimeSlotManager & timeSlotManager, NetworkInterfaceDriver & transceiver);		///< Initializes all relations needed by the instance.

	static NetworkEntity & instance();																		///< Returns reference to single instance.

protected:
	/**
	 * @brief Holds event information.
	 */
    struct EventElement
    {
        EventElement(EvId id, const SharedByteBuffer & data)
         : id(id), data(data)
        {}

        EvId id;						///< Event identifier (ex. EVID_JOYSTICK).
        const SharedByteBuffer data;	///< Data that goes together with the event.
    };

	// desenet::NetworkInterfaceDriver::Callback callback
protected:
	/**
	 * @brief Called by the lower layer after reception of a new frame
	 */
	virtual void onReceive(NetworkInterfaceDriver & driver, const uint32_t receptionTime, const uint8_t * const buffer, size_t length);


	/**
	 * @brief to register application that need synchronisation
	 *
	 * @param pApp the pointer to the app to be registered
	 */
	void svSyncRequest(AbstractApplication* pApp); // TODO : pushback appSyncList

	/**
	 * @brief To register application to publish values
	 *
	 * @param pApp the pointer to the app to be registered
	 */
    bool svPublishRequest(SvGroup group, AbstractApplication* pApp); // TODO : publish array

	// TODO : add observer method from ITimeSlotManager
	/**
	 * @brief Method called on the observer to notify new signal.
	 *
	 * @param timeSlotManager TimeSlotManager who sends the signal.
	 * @param signal The signal raised.
	 */
	virtual void onTimeSlotSignal(const ITimeSlotManager & timeSlotManager, const ITimeSlotManager::SIG & signal);

	/**
	 * @brief used by event application
	 *
	 * @param id Event ID
	 * @param evData Buffer with event data
	 */
	void evPublishRequest(EvId id, const SharedByteBuffer & evData);

protected:
	inline ITimeSlotManager & timeSlotManager() const { assert(_pTimeSlotManager); return *_pTimeSlotManager; }	///< Internal access to TimeSlotManager
	inline NetworkInterfaceDriver & transceiver() const { assert(_pTransceiver); return *_pTransceiver; }		///< Internal access to Transceiver

protected:


	typedef std::list<AbstractApplication *> ApplicationSyncList;		// TODO : subscribe abstract application (ex. accelerometer)
	typedef std::array<AbstractApplication *, 16> ApplicationPublishersArray;
	typedef std::list<EventElement> EventElementList;

protected:
	static NetworkEntity * _pInstance;				///< Pointer to single instance.
	ITimeSlotManager * _pTimeSlotManager;			///< Pointer to TimeSlotManager.
	NetworkInterfaceDriver * _pTransceiver;			///< Pointer to transceiver.

	// TODO: Add needed attributes here

private:
	ApplicationSyncList appSyncList;		///< list to register abstract application
	ApplicationPublishersArray appPublisharray;  ///< array of publishers app
	MultiPDU multiPDU; 							///< multiPDU frame
	EventElementList eventsList; 				///< List to store events that need to be sended
};

} // sensor
} // desenet
#endif // SENSOR_NETWORK_ENTITY_H
