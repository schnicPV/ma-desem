/*
 * multipdu.h
 *
 *  Created on: Dec 9, 2019
 *      Author: desem
 */

#ifndef DESENET_MULTIPDU_H_
#define DESENET_MULTIPDU_H_

#pragma once
#include <string>
#include "frame.h"
#include "types.h"

namespace desenet{

class MultiPDU: public Frame
{
public:
	MultiPDU();
	virtual ~MultiPDU();

	/**
	 * @brief return the address of the buffer needed to store svApp data
	 *
	 * @return the SharedByteBuffer address
	 */
	SharedByteBuffer& getSampledValuesBuffer();

    /**
     * @brief use to retreive the buffer containing the frame. (protected from frame class)
     *
     * @return Pointer to the buffer containing the multiPDU frame
     */
    uint8_t * getFrameBuffer()
	{
		return Frame::buffer();
	}

    /**
     * @brief update the content of the frame
     *
     * @param group the group number
     * @param appDataLength number of byte for the payload
     */
	void updateMPDU(SvGroup group, SharedByteBuffer::sizeType appDataLength);

	/**
	 * @brief reset the pdu counter and frame length
	 */
	void clean();

	/**
	 * @brief try to insert an event into the multipdu
	 */
	bool tryInsertEv(desenet::EvId eventId, const SharedByteBuffer& data);
private:
    SharedByteBuffer sampledValuesBuffer; // the buffer that will store svApp data
};

}



#endif /* DESENET_MULTIPDU_H_ */
