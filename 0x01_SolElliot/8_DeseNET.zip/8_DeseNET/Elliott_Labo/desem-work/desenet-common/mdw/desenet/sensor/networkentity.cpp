#include <assert.h>
#include <array>
#include <list>
#include <map>
#include <vector>
#include <utility>
#include "platform-config.h"
#include "desenet/frame.h"
#include "desenet/beacon.h"
#include "abstractapplication.h"
#include "factory.h"
#include "board/ledcontroller.h"
#include "networkentity.h"

using std::array;
using std::list;
using std::map;
using std::make_pair;
using std::bind;
using std::pair;
using std::vector;

using desenet::sensor::NetworkEntity;

NetworkEntity * NetworkEntity::_pInstance(nullptr);		// Instantiation of static attribute

#define MAX_GROUP_ALLOWED 16

NetworkEntity::NetworkEntity()
 : _pTimeSlotManager(nullptr),
   _pTransceiver(nullptr),
	multiPDU()
{
	assert(!_pInstance);		// Only one instance allowed
	_pInstance = this;

	for(int i = 0;i < 16; i++)
	{
		// default value for publisher array
		appPublisharray[i] = NULL;
	}
}

NetworkEntity::~NetworkEntity()
{
}

void NetworkEntity::initialize()
{
}

void NetworkEntity::initializeRelations(ITimeSlotManager & timeSlotManager, NetworkInterfaceDriver & transceiver)
{
	_pTimeSlotManager = &timeSlotManager;
	// TODO : initialize relations of timeSlotManager with this class
	timeSlotManager.initializeRelations(*this); // give reference to this class that is an observer on ITImeSlotManager
    _pTransceiver = &transceiver;

     // Set the receive callback between transceiver and network. Bind this pointer to member function
    transceiver.setReceptionHandler(std::bind(&NetworkEntity::onReceive, this, std::placeholders::_1, std::placeholders::_2, std::placeholders::_3, std::placeholders::_4));
}

/**
 * This method does not automatically create an instance if there is none created so far.
 * It is up the the developer to create an instance of this class prior to access the instance() method.
 */
//static
NetworkEntity & NetworkEntity::instance()
{
	assert(_pInstance);
	return *_pInstance;
}

/**
 * Called by the NetworkInterfaceDriver (layer below) after reception of a new frame
 */
void NetworkEntity::onReceive(NetworkInterfaceDriver & driver, const uint32_t receptionTime, const uint8_t * const buffer, size_t length)
{

	UNUSED(driver);
	//UNUSED(receptionTime);
	Frame frame = Frame::useBuffer(buffer, length);
	// TODO: Add your code here
	// I have to wait (n+1)*slotDuration before respond => 16+1 *50ms
	// look as sequence diagram when beacon arrive
	// 1) check if that's a beacon frame
	// 2) create it if it's true
	// 3) call timerSlotManager to let him know that a beacon as been received (use of slotDuration)
	// 4) notify all svApp -> sync
	// 5) go trough all svApp registered
	// 6) check if at this index an svApp is registered
	// 7) check if the gateway has asked for values of this svGroup
	// 8) retreive  data, with the desenet::SharedByteBuffer (that is part of the multiPDU)
	// 9) commit changes to the multiPDU, length of frame adaptation

	// 1) check if frame is a beacon
	if(frame.type() == desenet::FrameType::Beacon)
	{
		// 2) create the beacon
		Beacon beacon(frame);
		// 3) start timer with slot duration depending on value sended into beacon
		_pTimeSlotManager->onBeaconReceived(beacon.slotDuration());
		// 4) notify all svApp for synch
		// go trough sampled values app, call sync indication
		for (auto const& i : appSyncList) {
			i->svSyncIndication(beacon.networkTime());
		}
		// 5) go trough svApp's
		for(int i = 0; i < 16/*appPublisharray.size()*/; i++)
		{
			// 6) check if an app is registered at this index
			if(appPublisharray[i] != NULL)
			{
				// 7) check is gateway has asked for values of this group
				if(beacon.svGroupMask()[i] == true)
				{
					// 8) retreive data from svApp
					SharedByteBuffer::sizeType appDataLength; // nBytes returned svApp on publish indication
					appDataLength = appPublisharray[i]->svPublishIndication(i, multiPDU.getSampledValuesBuffer());
					// 9) adapt lenght of multiPDU
					multiPDU.updateMPDU(i, appDataLength);
				}
			}
		}
	}

}

// TODO: Add missing class method implementations here

/**
 * store application that need syncro
 */
void NetworkEntity::svSyncRequest(AbstractApplication* pApp)
{
	// register app to sync list
	appSyncList.push_back(pApp);
}

/**
 * used by applications that publish sampled values
 */
bool NetworkEntity::svPublishRequest(SvGroup group, AbstractApplication* pApp)
{
	// check if group is already filled, only one app per group allowed, max group 15
	if(group < MAX_GROUP_ALLOWED)
	{
		if(appPublisharray.at(group) != NULL) return false; // no app registered with at this svgroup
		else appPublisharray.at(group) = pApp; // register app, to let it publish
		return true;
	}
	else
	{
		return false;	// group number out of range
	}

}

// ITimeSlotManager observer
void NetworkEntity::onTimeSlotSignal(const ITimeSlotManager & timeSlotManager, const ITimeSlotManager::SIG & signal)
{
	if (signal == ITimeSlotManager::OWN_SLOT_START) {  // start slot now

		// TODO: check time !!! this can be longer than expected...
		while (eventsList.empty() != true)
		{   // insert the event into the multipdu
			bool attempt = multiPDU.tryInsertEv(eventsList.front().id, eventsList.front().data);
			if(attempt == true)
			{
				// event has been inserted into the frame, remove it from list
				eventsList.pop_front();
			}
		}

		// go transmit on the air (done by the transceiver)
		_pTransceiver->transmit(multiPDU.getFrameBuffer(), multiPDU.length());
		multiPDU.clean(); // erase multipdu data for next one
	}
}

/**
 * used by applications that publish events
 */
void NetworkEntity::evPublishRequest(EvId id, const SharedByteBuffer & evData)
{
	eventsList.push_back(EventElement(id, evData)); // add event to the list
}
