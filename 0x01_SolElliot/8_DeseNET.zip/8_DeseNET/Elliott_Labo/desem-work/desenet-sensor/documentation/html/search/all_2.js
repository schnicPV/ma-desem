var searchData=
[
  ['beacon',['Beacon',['../classdesenet_1_1Beacon.html',1,'desenet::Beacon'],['../classdesenet_1_1Beacon.html#a2566f46598c15340fcda82ab94e020d4',1,'desenet::Beacon::Beacon(uint32_t cycleInterval=0)'],['../classdesenet_1_1Beacon.html#a95e5906a5e18c99bf62115de76da6ec5',1,'desenet::Beacon::Beacon(const Frame &amp;frame)']]],
  ['beaconnetworktime',['beaconNetworkTime',['../classdesenet_1_1gateway_1_1NetworkEntity.html#aa53cc24567d1ce904f1ae5271220a372',1,'desenet::gateway::NetworkEntity']]],
  ['buffer',['buffer',['../classdesenet_1_1Frame.html#a1cdd016bedc5b4fa03fcffe8c67d1c96',1,'desenet::Frame::buffer()'],['../classdesenet_1_1Frame.html#a20c35482fc9525af7c9bae1d2f727508',1,'desenet::Frame::buffer() const']]]
];
