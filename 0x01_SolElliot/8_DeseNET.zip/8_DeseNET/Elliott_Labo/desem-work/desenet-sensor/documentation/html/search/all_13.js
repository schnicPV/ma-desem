var searchData=
[
  ['usebuffer',['useBuffer',['../classdesenet_1_1Frame.html#a2830da69510195c7c7743c7b5cf4cf85',1,'desenet::Frame::useBuffer(std::uint8_t *buffer, std::size_t length)'],['../classdesenet_1_1Frame.html#a7050a16c79e17c23134395b836cfb3b1',1,'desenet::Frame::useBuffer(const std::uint8_t *const buffer, std::size_t length)']]]
];
