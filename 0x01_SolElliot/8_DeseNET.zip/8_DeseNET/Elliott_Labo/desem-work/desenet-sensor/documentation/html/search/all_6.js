var searchData=
[
  ['factory',['Factory',['../classFactory.html',1,'']]],
  ['footer_5fsize',['FOOTER_SIZE',['../classdesenet_1_1Frame.html#a62c6573e3d4f093713945b90d5952a68',1,'desenet::Frame']]],
  ['frame',['Frame',['../classdesenet_1_1Frame.html',1,'desenet::Frame'],['../classdesenet_1_1Frame.html#a45da075af2d45001db031208c55ac743',1,'desenet::Frame::Frame()']]],
  ['friendlyname',['friendlyName',['../classdesenet_1_1NetworkInterfaceDriver_1_1Descriptor.html#ad1dfd130dfc71984ad9d0f42bc911413',1,'desenet::NetworkInterfaceDriver::Descriptor']]],
  ['fromhexstring',['fromHexString',['../classphy_1_1Address.html#ae2a746743950db904bb3119624d2040c',1,'phy::Address']]],
  ['frequently_20asked_20questions',['Frequently asked Questions',['../sec_faq.html',1,'index']]]
];
