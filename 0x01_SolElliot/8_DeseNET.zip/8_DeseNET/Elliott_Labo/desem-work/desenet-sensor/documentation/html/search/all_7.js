var searchData=
[
  ['gateway',['GATEWAY',['../classdesenet_1_1gateway_1_1NetworkEntity.html#af3278da660bd2fb0cd8c3ea63ff49648a17da06968e21e0aaf62201cc642ccfd4',1,'desenet::gateway::NetworkEntity']]]
];
