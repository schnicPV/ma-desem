#include "joystickapp.h"
#include "platform-config.h"
#include "trace/trace.h"
#include "factory.h"
#include "xf/xfevent.h"


using app::JoystickApp;

JoystickApp::JoystickApp():
		buffer(1) // 1 byte necessary for joystick position
{

}

/**
 * from IJoystickObserver
 */
void JoystickApp::onPositionChange( IJoystick::Position position )
{
	memcpy(buffer.data(), &position, 1);
	AbstractApplication::evPublishRequest(EVID_JOYSTICK, buffer);
}
