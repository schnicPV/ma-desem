#ifndef JOYSTICKAPP_H
#define JOYSTICKAPP_H

#include "platform-config.h"
#include "xf/xfreactive.h"
#include "desenet/sensor/abstractapplication.h"
#include "platform/platform-common/board/interfaces/ijoystickobserver.h"
#include "joystick.h"


namespace app
{


/**
 * @brief Application that sends joystick events to the gateway node
 */
class JoystickApp :	public desenet::sensor::AbstractApplication,
							public IJoystickObserver
{
public:
	/**
	 * @brief Constructor
	 */
	JoystickApp();

	/**
	 * @brief This method is called by the Joystick object whenever the position
	 * of the hardware joystick changes.
	 *
	 * @param position The actual position of the joystick, coded according to the IJoystick::Position enumeration.
	 */
	void onPositionChange( IJoystick::Position position );

private:
	desenet::SharedByteBuffer buffer; ///< Buffer allowing to transmit data up to the mutliPDU frame
};

} // namespace app

#endif // JOYSTICKAPP_H
