#ifndef MENU_H
#define MENU_H

/**
 * @brief The Menu class
 *
 * console definition :
 *
 * 1 draw line
 * 2 draw circle
 * 3 draw rectangle
 * 4 show drawings
 * 9 quit
 */

#include <iostream>
#include <vector>
#include "form.h"

using namespace std;

class Menu
{
public:
    Menu();

    void addLine();
    void addRectangle();
    void addCircle();

    char showMenu();

    void showDrawings();

    void quit();
private:
    vector<Form*> drawings;
};

#endif // MENU_H
