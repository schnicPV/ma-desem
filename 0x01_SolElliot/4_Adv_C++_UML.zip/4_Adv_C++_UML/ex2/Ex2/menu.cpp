#include "menu.h"

Menu::Menu()
{

}

char Menu::show()
{
    char choice;
    cout << "1 : Add Line" <<endl;
    cout << "2 : Add Rectangle" <<endl;
    cout << "3 : Add Circle" <<endl;
    cout << "4 : Show Forms" <<endl;
    cout << "9 : Exit" <<endl <<endl;
    cin >> choice;

    return choice;
}
