#ifndef BUTTON_H
#define BUTTON_H

#include "platform-config.h"
#include "xf/xfreactive.h"
#include "button-interface.h"

// Reactive class
class Button : public ToButton, public XFReactive
{
public:
	Button();
    virtual ~Button();

    /* Factory Pattern */
    void initialize();
    void initializeRelations(ToButtonManager * p);

    /* SAP Pattern */
    void setButtonManager(ToButtonManager * p);

    // for startBehavior() accessibility
    void start();

protected:
    virtual EventStatus processEvent();

private:
    BState checkButtonState();

private:
    ToButtonManager* pManager;			///< Pointer to button observer.
    BState state;						///< Holds the previous read button state.
};

#endif // BUTTON_H
