#include "stm32f10x_gpio.h"
#include "button.h"

Button::Button()
 : pManager(NULL),
   state(RELEASED)
{
}

Button::~Button()
{
}

void Button::initialize()
{

    // First init hardware needed (PC6 Pin as input for center joystick)
    GPIO_InitTypeDef gpioStruct;

    // PCLK2 must be enable logical AND (page 84 RM008, figure 8)
    // APB2 peripheral clock enable register (RCC_APB2ENR) (6.3.7) bit 4 IOPCEN setted
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE); // enable clock for the GPIO periph

    gpioStruct.GPIO_Pin = GPIO_Pin_6; // PC6 => pin 6 of GPIO port C
    gpioStruct.GPIO_Speed = GPIO_Speed_2MHz;
    gpioStruct.GPIO_Mode = GPIO_Mode_IN_FLOATING; // pull down hardware on bard, software set as floating
    GPIO_Init(GPIOC, &gpioStruct);


	// Read actual button state (GPIO state)
	// (It may be pressed already at start up!)
	state = checkButtonState();
}

void Button::initializeRelations(ToButtonManager * p)
{
	setButtonManager(p);
}

void Button::setButtonManager(ToButtonManager * p)
{
	pManager = p;
}

void Button::start()
{
    // reactive behavior launch (FSM)
    startBehavior();
}


BState Button::checkButtonState()
{
    bool pinState = GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_6);
    if(pinState)
    {
        return PRESSED;
    }
    else
    {
        return RELEASED;
    }
	//return state;
}

EventStatus Button::processEvent()
{
    eSmState newState = lastState;
    bool stateChanged = false;

    // fsm do not have processed the event yet
    EventStatus result = EventStatus::Unknown;

    // the 'transition' switch
    switch (lastState)
    {
    case STATE_INIT:
        if (getCurrentEvent()->getEventType() == IXFEvent::Initial)
        {
            newState = STATE_INIT;  // Stay in state
            stateChanged = true;    // Allow to execute 'action on entry' for new state
        }
        else if (getCurrentEvent()->getEventType() == IXFEvent::NullTransition)
        {
            newState = STATE_WAIT;
            stateChanged = true;    // Allow to execute 'action on entry' for new state
        }
        break;
    case STATE_WAIT:
        if (getCurrentEvent()->getEventType() == IXFEvent::Timeout &&
            getCurrentTimeout()->getId() == tmPollId)
        {
            newState = STATE_WAIT;  // Stay in state
            stateChanged = true;    // Allow to execute 'action on entry' for new state
        }
        break;
    }

    // the 'action on entry' switch
    if (stateChanged)
    {
        result = EventStatus::Consumed;
        switch (newState)
        {
        case STATE_INIT:
            GEN(XFNullTransition());
            break;
        case STATE_WAIT:
            // Launch an other timeout
            getThread()->scheduleTimeout(tmPollId, 20, this);

            // Execute on transition code
            doHandleButtonState();
            break;
        }

        lastState = newState;
    }
    return result;
}


