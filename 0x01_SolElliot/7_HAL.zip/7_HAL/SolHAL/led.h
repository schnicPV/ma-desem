#ifndef LED_H_
#define LED_H_

class Led
{
public:
	void initialize();
	void turnOn();
	void turnOff();
};

#endif
