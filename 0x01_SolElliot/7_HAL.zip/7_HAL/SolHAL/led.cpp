// platform/olimex-stm32f103-stk/board

// not useful because of led controller already do it

#include "stm32f10x_gpio.h"
#include "board/led.h"

void Led::initialize()
{
	// Code taken from LedController class
	GPIO_InitTypeDef gpioInitStructure;

	// Enable needed clocks
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);

    // Configure PC.12 as output push-pull (LED)
    GPIO_WriteBit(GPIOC,GPIO_Pin_12,Bit_SET); // not necessary, first write
    gpioInitStructure.GPIO_Pin =  GPIO_Pin_12;
    gpioInitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    gpioInitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOC, &gpioInitStructure);
}

void Led::turnOn()
{
	GPIO_WriteBit(GPIOC, GPIO_Pin_12, Bit_RESET);	// Code taken from LedController class
}

void Led::turnOff()
{
	GPIO_WriteBit(GPIOC, GPIO_Pin_12, Bit_SET);		// Code taken from LedController class
}
