#ifndef BUTTON_H
#define BUTTON_H

#include "platform-config.h"
#include "xf/xfreactive.h"
#include "button-interface.h"

class Button : public ToButton,
			   public XFReactive
{
public:
	Button();
    virtual ~Button();

    /* Factory Pattern */
    void initialize();
    void initializeRelations(ToButtonManager * p);

    /* SAP Pattern */
    void setButtonManager(ToButtonManager * p);

    void start();

protected:
    void initializeHardware();				///< Initializes hardware needed by this class.
    virtual EventStatus processEvent(); 	///< Implements the state machine for this class.
    void doHandleButtonState();				///< Method call in state machine.

private:
    BState checkButtonState();
    bool readGpio();

private:
    enum eSmState {STATE_INIT, STATE_WAIT};		///< State machine states.
    enum tmId {tmPollId = 5};					///< State machine timeout identifier(s).

    ToButtonManager* pManager;			///< Pointer to button observer.
    BState state;						///< Holds the previous read button state.
    eSmState lastState;					///< Holds the actual (last calculated) state of the state machine.
};

#endif // BUTTON_H
