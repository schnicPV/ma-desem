// platform/olimex-stm32f103-stk/board

#include "stm32f10x_gpio.h"
#include "button.h"

Button::Button()
 : pManager(NULL),
   state(RELEASED),
   lastState(STATE_INIT)
{
}

Button::~Button()
{
}

void Button::initialize()
{
	// Initialize hardware
	initializeHardware();

	// Read actual button state (GPIO state)
	// (It may be pressed already at start up!)
	state = checkButtonState();
}

void Button::initializeHardware()
{
	/**
	 * The center button of the olimex's board
	 * joystick is on MCU pin PC6.
	 *
	 */

	GPIO_InitTypeDef gpioInitStructure;

	// Enable needed clock of peripheral
    // PCLK2 must be enable logical AND (page 84 RM008, figure 8)
    // APB2 peripheral clock enable register (RCC_APB2ENR) (6.3.7) bit 4 IOPCEN setted
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE); // enable clock for the GPIO periph

	// Set up GPIOC pin 6 as input
	gpioInitStructure.GPIO_Pin = GPIO_Pin_6; // PC6 => pin 6 of GPIO port C
	gpioInitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	gpioInitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING; // pull down hardware on bard, software set as floating
    GPIO_Init(GPIOC, &gpioInitStructure);
}

void Button::initializeRelations(ToButtonManager * p)
{
	setButtonManager(p);
}

void Button::setButtonManager(ToButtonManager * p)
{
	pManager = p;
}

void Button::start()
{
	startBehavior();	// Start state machine
}

BState Button::checkButtonState()
{
	if (readGpio())
	{
		return PRESSED;
	}
	return RELEASED;
}

bool Button::readGpio()
{
    // act as a "schmitt trigger"
    // could be casted as bool
	return !!GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_6);
}

EventStatus Button::processEvent()
{
    // software debouncing at 20ms

	eSmState newState = lastState;
	bool stateChanged = false;
    // will we handle the event ?
    EventStatus result = EventStatus::Unknown;

	// the 'transition' switch
	switch (lastState)
	{
    case STATE_INIT:
    	if (getCurrentEvent()->getEventType() == IXFEvent::Initial)
    	{
        	newState = STATE_INIT;	// Stay in state
        	stateChanged = true;	// Allow to execute 'action on entry' for new state
    	}
    	else if (getCurrentEvent()->getEventType() == IXFEvent::NullTransition)
    	{
    		newState = STATE_WAIT;
    		stateChanged = true;	// Allow to execute 'action on entry' for new state
    	}
    	break;
    case STATE_WAIT:
    	if (getCurrentEvent()->getEventType() == IXFEvent::Timeout &&
    		getCurrentTimeout()->getId() == tmPollId)
    	{
        	newState = STATE_WAIT;	// Stay in state
    		stateChanged = true;	// Allow to execute 'action on entry' for new state
    	}
    	break;
	}

    // the 'action on entry' switch
    if (stateChanged)
    {
        result = EventStatus::Consumed;
        switch (newState)
        {
        case STATE_INIT:
        	GEN(XFNullTransition());
        	break;
        case STATE_WAIT:
        	// Launch an other timeout
    		getThread()->scheduleTimeout(tmPollId, 20, this);

    		// Execute on transition code
    		doHandleButtonState();
        	break;
        }

        lastState = newState;
    }
    return result;
}

void Button::doHandleButtonState()
{
	const BState actualState = checkButtonState();

	if (actualState != state)	// Any change?
	{
		if (actualState == PRESSED)
		{
			pManager->pressed(); // call SAP of btnManager
		}
		else
		{
			pManager->released();
		}

		state = actualState;	// Store actual state for next time
	}
}
