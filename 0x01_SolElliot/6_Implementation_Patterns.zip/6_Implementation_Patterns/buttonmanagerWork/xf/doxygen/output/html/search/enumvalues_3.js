var searchData=
[
  ['terminate',['Terminate',['../class_i_x_f_event.html#a7840ab36d404772a79564db02ffbdd19ad51bfd7c34cd809378fb012355d2df30',1,'IXFEvent']]],
  ['timeout',['Timeout',['../class_i_x_f_event.html#a7840ab36d404772a79564db02ffbdd19a2071ca5416f8002d8357481b9e2ce329',1,'IXFEvent']]]
];
