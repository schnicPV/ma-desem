var searchData=
[
  ['_5fteventstatus',['_tEventStatus',['../struct_i_x_f_event_1_1__t_event_status.html',1,'IXFEvent']]]
];
