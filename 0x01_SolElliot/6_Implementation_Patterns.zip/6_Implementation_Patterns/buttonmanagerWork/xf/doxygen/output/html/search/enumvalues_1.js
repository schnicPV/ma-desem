var searchData=
[
  ['initial',['Initial',['../class_i_x_f_event.html#a7840ab36d404772a79564db02ffbdd19abdcb651437425a46f9679ff397348ee3',1,'IXFEvent']]]
];
